
		   Legal Notices & Public Source Code

Wind River provides the required third party legal notices and open source code
when a product is downloaded. That is, the required IP compliance artifacts 
for a given product are provided at the same time and the same place using the
same delivery mechanism as the product. You can also log on to your Wind River 
delivery account to obtain copies of the compliance artifacts for each product 
you have purchased.

